from application.models import db, User, Role, Service, ServiceProfessional, ServiceRequest, Customer
from datetime import date
from main import app
from werkzeug.security import generate_password_hash
from application.security import datastore

def add_data_to_database(app):
    with app.app_context():
        # Roles
        roles = ['admin', 'customer', 'serviceprofessional']
        for role_name in roles:
            role = Role.query.filter_by(name=role_name).first()
            if not role:
                role = Role(name=role_name)
                db.session.add(role)
        db.session.commit()

        admin_role = Role.query.filter_by(name='admin').first()
        customer_role = Role.query.filter_by(name='customer').first()
        professional_role = Role.query.filter_by(name='serviceprofessional').first()

        # Adding admin
        if not datastore.find_user(email="admin@housekart.com"):
            admin_user = datastore.create_user(
                email="admin@housekart.com", 
                password=generate_password_hash("admin"), 
                roles=[admin_role]
            )
            db.session.commit()

        # Dummy customers
        customers = [
            {
                'email': f'customer{i}@example.com',
                'full_name': f'Customer {i}',
                'password': '12345678',
                'contact': f'123456789{i}',
                'address': f'Address {i}',
                'pincode': f'5600{i}',
            } for i in range(2, 7)
        ]

        # Dummy professionals with active status
        professionals = [
            {
                'email': f'professional{i}@example.com',
                'full_name': f'Professional {i}',
                'password': '12345678',
                'contact': f'987654321{i}',
                'service_type': f'Service Type {i}',
                'service_description': f'Service Description {i}',
                'experience': f'{i+1} years',
                'document': f'Document {i}',
                'address': f'Professional Address {i}',
                'pincode': f'5601{i}',
                'is_approved': True if i % 2 == 0 else False
            } for i in range(2, 7)
        ]

        # Creating Customers
        for customer in customers:
            if not datastore.find_user(email=customer['email']):
                user = datastore.create_user(
                    email=customer['email'], 
                    password=generate_password_hash(customer['password']), 
                    roles=[customer_role]
                )
                db.session.commit()
                db_customer = Customer(
                    user_id=user.id,
                    email=customer['email'],
                    full_name=customer['full_name'],
                    password=customer['password'],
                    contact=customer['contact'],
                    address=customer['address'],
                    pincode=customer['pincode'],
                )
                db.session.add(db_customer)
        db.session.commit()

        # Creating Service Professionals
        for professional in professionals:
            if not datastore.find_user(email=professional['email']):
                user = datastore.create_user(
                    email=professional['email'], 
                    password=generate_password_hash(professional['password']), 
                    roles=[professional_role], 
                    active=professional['is_approved']
                )
                db.session.commit()
                db_professional = ServiceProfessional(
                    user_id=user.id,
                    email=professional['email'],
                    full_name=professional['full_name'],
                    password=professional['password'],
                    contact=professional['contact'],
                    service_type=professional['service_type'],
                    service_description=professional['service_description'],
                    experience=professional['experience'],
                    document=professional['document'],
                    address=professional['address'],
                    pincode=professional['pincode'],
                    is_approved=professional['is_approved']
                )
                db.session.add(db_professional)
        db.session.commit()

        print('Data successfully added to the database.')

add_data_to_database(app)
