export default{
    template: `<div>Welcome Service Details</div>`,
    data(){
        return{}
    },
}