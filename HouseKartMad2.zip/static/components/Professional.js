export default{
    template : `<div> Profesional dashboard</div>`
}